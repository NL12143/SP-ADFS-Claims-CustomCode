//===============================================================================
// Microsoft patterns & practices
// Cliams Identity Guide V2
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://claimsid.codeplex.com/license)
//===============================================================================


using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FShipping")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyProduct("FShipping")]
[assembly: ComVisible(false)]
[assembly: Guid("61904fa5-77d6-4653-9091-6a4a1a6c6742")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]