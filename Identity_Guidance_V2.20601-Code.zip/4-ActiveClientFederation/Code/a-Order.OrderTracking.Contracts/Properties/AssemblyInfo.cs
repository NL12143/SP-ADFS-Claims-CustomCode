//===============================================================================
// Microsoft patterns & practices
// Cliams Identity Guide V2
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://claimsid.codeplex.com/license)
//===============================================================================


using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("a-Order.OrderTracking.Contracts")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyProduct("Claims Identity Guide V2")]
[assembly: ComVisible(false)]
[assembly: Guid("30743fe6-3c97-47e4-81dc-8382107b7014")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]